#include "../include/ArbolN.hpp"
#include <list>
#include <iostream>
#include <string>
#include <sstream>
#include <limits>
#include <cctype>
#include <vector>

void esOpeAlcanzable(ArbolN<int> a, int posicionV, const vector<int> &valoresEstabilidad, vector<int> &alcanzables);

int main(){
    int t;
    cin >> t;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    bool esPrimeraLinea = true;
    
    for(int caso = 1; caso <= t; caso++){
        int cantidadNodos;
        cin >> cantidadNodos;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        // Leer eficiencias locales
        vector<int> valoresEstabilidad;
        for(int i = 0; i < cantidadNodos; i++){
            int efi;
            cin >> efi;
            valoresEstabilidad.push_back(efi);
        }

        /*
        // Verificar las eficicias locales (DEBUGGER)
        for (size_t i = 0; i < valoresEstabilidad.size(); ++i) {
            cout << valoresEstabilidad[i] << " ";
        }

        // Ignora salto de línea
        cout << endl; // (DEBUGGER)
        */
        
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        // Leer Árbol por entrada estándar
        ArbolN<int> arbol;
        for(int nodos = 0; nodos < cantidadNodos -1; nodos++){
            int padre, hijo;
            cin >> padre >> hijo;
            //cout << "insertar: " <<padre << " " << hijo << endl; // (DEBUGGER)
            if(nodos == 0){
                arbol.insertarNodo(0, padre);
                arbol.insertarNodo(padre, hijo);
            }else{
                arbol.insertarNodo(padre, hijo);
            }
        }
        //arbol.imprimirJerarquico(); // (DEBUGGER)
        //cout << endl; // (DEBUGGER)

        // Resolucion del ejercicio
        // Llenado de vector de alcanzables estilo grafos
        vector<int> alcanzables;
        for(int i = 0; i < arbol.getPeso(); i++){
            alcanzables.push_back(0);
        }
        // Reviso si los elementos no marcados son alcanzables o no
        Lista<int> recorrido = arbol.preOrden();
        int i = 0;
        while(!recorrido.esVacia()){
            int posicionV = recorrido.consultar(1);

            //cout << "keloke " << valoresEstabilidad.at(i) << " a "; // (DEBUGGER)

            // si el elemento no fue alcanzado no lo recorre
            if(alcanzables.at(i) == 0){
                //cout << "mamaguevo"; // (DEBUGGER)
                esOpeAlcanzable(arbol, posicionV, valoresEstabilidad, alcanzables);
            }
            i++;
            recorrido.eliminar(1);
        }

        /*
        // Verificar las eficicias locales (DEBUGGER)
        for (size_t i = 0; i < alcanzables.size(); ++i) {
            cout << "->" << alcanzables[i] << " ";
        }
        */
        
        // sumo las posiciones que mantuvieron su alcanzabilidad
        int posAlcanzables = 0;
        for(int i = 0; i < arbol.getPeso(); i++){
            if(alcanzables[i] == 1) posAlcanzables += 1;
        }

        // retorno y evito una linea vacia al final
        if(esPrimeraLinea){
            cout << posAlcanzables << endl;
        }else{
            cout << endl << posAlcanzables;
        }
    }
    return 0;
}
void esOpeAlcanzable(ArbolN<int> a, int posicionV, const vector<int> &valoresEstabilidad, vector<int> &alcanzables) {
    Lista<int> camino;
    int estabilidadAcumulada = 0;

    camino = a.camino(a.getRaiz(), posicionV);
    //cout << camino << "  "; // (DEBUGGER)
    while(!camino.esVacia() && estabilidadAcumulada >= 0){
        // revisa el token del vector y evita leaks
        int idNodo = camino.consultar(1);
        // cout << idNodo << endl; // (DEBUGGER)
        if(idNodo <= 0 || idNodo > (int)valoresEstabilidad.size()){
            throw out_of_range("ID de nodo fuera de rango para eficienciasLocales");
        }

        estabilidadAcumulada += valoresEstabilidad.at(idNodo - 1);
        // cout << " ea: " << estabilidadAcumulada << endl; // (DEBUGGER)

        // si la suma acumulada se mantiene mayor a 0 entonces marco el nodo como alcanzable para no recorrerlo luego
        if(estabilidadAcumulada >= 0) alcanzables[idNodo - 1] = 1;
        camino.eliminar(1);
    }

    // Marca los elemenos del camino que no sean alcanzables
    while(!camino.esVacia()){
        int idNodo = camino.consultar(1);
        if(idNodo <= 0 || idNodo > (int)valoresEstabilidad.size()){
            throw out_of_range("ID de nodo fuera de rango para eficienciasLocales");
        }

        alcanzables[idNodo - 1] = -1;
        camino.eliminar(1);
    }
}